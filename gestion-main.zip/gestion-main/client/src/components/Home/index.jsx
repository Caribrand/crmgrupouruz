import ButtonsOptions from "./ButtonsOptions/ButtonsOptions";
import Navbar from "./Navbar/Navbar";



function Index() {
  return (
    <div >
      <Navbar/>
      <ButtonsOptions/>
    </div>
  );
}

export default Index;
